from __future__ import annotations

import json
import time
from typing import Any

from nlp.memory.services import MemoryStore


class WorkingMemoryService:
    """
    Captures executed commands and stores them in memory_command_history.

    This does NOT influence behavior yet.
    It only records what happened.
    """

    def __init__(self, store: MemoryStore):
        self.store = store

    def record_command(
        self,
        *,
        transcript: str,
        intent_name: str | None,
        intent_confidence: float | None,
        device_id: str | None,
        room_id: str | None,
        slots: dict[str, Any] | None,
        source_endpoint_id: str | None = None,
        outcome: str | None = None,
        request_id: str | None = None,
    ) -> None:

        conn = self.store._connect()

        conn.execute(
            """
            INSERT INTO memory_command_history (
                project_id,
                ts,
                source,
                source_endpoint_id,
                room_id,
                request_id,
                raw_text,
                intent_name,
                intent_confidence,
                device_id,
                outcome,
                slots_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                self.store.default_project_id,
                time.time(),
                "voice",
                source_endpoint_id,
                room_id,
                request_id,
                transcript,
                intent_name,
                intent_confidence,
                device_id,
                outcome,
                json.dumps(slots or {}),
            ),
        )

        conn.commit()
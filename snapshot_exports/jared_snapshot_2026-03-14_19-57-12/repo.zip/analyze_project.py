from __future__ import annotations

from pathlib import Path
from collections import defaultdict
from typing import TypedDict

from radon.raw import analyze
from radon.complexity import cc_visit
from radon.metrics import mi_visit


EXCLUDE_DIRS = {
    ".git",
    ".venv",
    ".venv-tts",
    "__pycache__",
    "node_modules",
    "data",
    "third_party",
    "logs",
    "tflite_runtime",
}

TOP_N_FILES = 20
TOP_N_COMPLEX = 15


class FileStats(TypedDict):
    loc: int
    lloc: int
    sloc: int
    comments: int
    multi: int
    blank: int
    complexity_total: int
    complexity_blocks: int
    complexity_avg: float
    max_block_complexity: int
    mi: float
    error: str | None


class FolderStats(TypedDict):
    files: int
    loc: int
    lloc: int
    sloc: int
    comments: int
    complexity_total: int
    mi_values: list[float]
    avg_mi: float


class TotalStats(TypedDict):
    files: int
    loc: int
    lloc: int
    sloc: int
    comments: int
    multi: int
    blank: int
    complexity_total: int
    mi_values: list[float]
    error_files: int
    avg_mi: float


def make_folder_stats() -> FolderStats:
    return {
        "files": 0,
        "loc": 0,
        "lloc": 0,
        "sloc": 0,
        "comments": 0,
        "complexity_total": 0,
        "mi_values": [],
        "avg_mi": 0.0,
    }


def should_skip(path: Path) -> bool:
    return any(part in EXCLUDE_DIRS for part in path.parts)


def analyze_file(path: Path) -> FileStats:
    try:
        code = path.read_text(encoding="utf-8", errors="ignore")
        raw = analyze(code)
        complexity_blocks = cc_visit(code)
        mi_score = float(mi_visit(code, True))

        total_complexity = sum(block.complexity for block in complexity_blocks)
        max_block_complexity = max(
            (block.complexity for block in complexity_blocks),
            default=0,
        )

        return {
            "loc": raw.loc,
            "lloc": raw.lloc,
            "sloc": raw.sloc,
            "comments": raw.comments,
            "multi": raw.multi,
            "blank": raw.blank,
            "complexity_total": total_complexity,
            "complexity_blocks": len(complexity_blocks),
            "complexity_avg": (
                total_complexity / len(complexity_blocks) if complexity_blocks else 0.0
            ),
            "max_block_complexity": max_block_complexity,
            "mi": mi_score,
            "error": None,
        }
    except Exception as e:
        return {
            "loc": 0,
            "lloc": 0,
            "sloc": 0,
            "comments": 0,
            "multi": 0,
            "blank": 0,
            "complexity_total": 0,
            "complexity_blocks": 0,
            "complexity_avg": 0.0,
            "max_block_complexity": 0,
            "mi": 0.0,
            "error": str(e),
        }


def analyze_project(root: str):
    root_path = Path(root).resolve()

    results: dict[str, FileStats] = {}

    folder_totals: defaultdict[str, FolderStats] = defaultdict(make_folder_stats)

    total: TotalStats = {
        "files": 0,
        "loc": 0,
        "lloc": 0,
        "sloc": 0,
        "comments": 0,
        "multi": 0,
        "blank": 0,
        "complexity_total": 0,
        "mi_values": [],
        "error_files": 0,
        "avg_mi": 0.0,
    }

    for path in root_path.rglob("*.py"):
        if should_skip(path):
            continue

        rel_path = path.relative_to(root_path)
        stats = analyze_file(path)
        results[str(rel_path)] = stats

        if stats["error"] is not None:
            total["error_files"] += 1
            continue

        top_folder = rel_path.parts[0] if len(rel_path.parts) > 1 else "(root)"

        total["files"] += 1
        total["loc"] += stats["loc"]
        total["lloc"] += stats["lloc"]
        total["sloc"] += stats["sloc"]
        total["comments"] += stats["comments"]
        total["multi"] += stats["multi"]
        total["blank"] += stats["blank"]
        total["complexity_total"] += stats["complexity_total"]
        total["mi_values"].append(stats["mi"])

        folder = folder_totals[top_folder]
        folder["files"] += 1
        folder["loc"] += stats["loc"]
        folder["lloc"] += stats["lloc"]
        folder["sloc"] += stats["sloc"]
        folder["comments"] += stats["comments"]
        folder["complexity_total"] += stats["complexity_total"]
        folder["mi_values"].append(stats["mi"])

    total["avg_mi"] = (
        sum(total["mi_values"]) / len(total["mi_values"])
        if total["mi_values"] else 0.0
    )

    for folder in folder_totals.values():
        folder["avg_mi"] = (
            sum(folder["mi_values"]) / len(folder["mi_values"])
            if folder["mi_values"] else 0.0
        )

    return results, folder_totals, total


def print_project_summary(total: TotalStats) -> None:
    print("\n=== Project Summary ===")
    print(f"Files analyzed: {total['files']}")
    print(f"Files with errors: {total['error_files']}")
    print(f"Total LOC: {total['loc']}")
    print(f"Total SLOC: {total['sloc']}")
    print(f"Total LLOC: {total['lloc']}")
    print(f"Total Comments: {total['comments']}")
    print(f"Total Multiline Strings: {total['multi']}")
    print(f"Total Blank Lines: {total['blank']}")
    print(f"Total Cyclomatic Complexity: {total['complexity_total']}")
    print(f"Average Maintainability Index: {total['avg_mi']:.2f}")


def print_folder_summary(folder_totals: dict[str, FolderStats]) -> None:
    print("\n=== Folder Summary (by SLOC) ===")

    sorted_folders = sorted(
        folder_totals.items(),
        key=lambda item: item[1]["sloc"],
        reverse=True,
    )

    print(
        f"{'Folder':<20} {'Files':>5} {'LOC':>7} {'SLOC':>7} "
        f"{'LLOC':>7} {'Complexity':>12} {'Avg MI':>8}"
    )
    print("-" * 75)

    for folder_name, stats in sorted_folders:
        print(
            f"{folder_name:<20} "
            f"{stats['files']:>5} "
            f"{stats['loc']:>7} "
            f"{stats['sloc']:>7} "
            f"{stats['lloc']:>7} "
            f"{stats['complexity_total']:>12} "
            f"{stats['avg_mi']:>8.2f}"
        )


def print_largest_files(results: dict[str, FileStats], top_n: int = TOP_N_FILES) -> None:
    print(f"\n=== Top {top_n} Largest Files (by LOC) ===")

    valid = [(path, stats) for path, stats in results.items() if stats["error"] is None]
    valid.sort(key=lambda item: item[1]["loc"], reverse=True)

    print(f"{'File':<45} {'LOC':>6} {'SLOC':>6} {'LLOC':>6} {'Comments':>10} {'MI':>8}")
    print("-" * 90)

    for path, stats in valid[:top_n]:
        print(
            f"{path:<45.45} "
            f"{stats['loc']:>6} "
            f"{stats['sloc']:>6} "
            f"{stats['lloc']:>6} "
            f"{stats['comments']:>10} "
            f"{stats['mi']:>8.2f}"
        )


def print_most_complex_files(
    results: dict[str, FileStats],
    top_n: int = TOP_N_COMPLEX,
) -> None:
    print(f"\n=== Top {top_n} Most Complex Files ===")

    valid = [(path, stats) for path, stats in results.items() if stats["error"] is None]
    valid.sort(
        key=lambda item: (
            item[1]["complexity_total"],
            item[1]["max_block_complexity"],
        ),
        reverse=True,
    )

    print(
        f"{'File':<45} {'Total':>7} {'MaxBlk':>7} {'Blocks':>7} "
        f"{'AvgBlk':>8} {'LOC':>6} {'MI':>8}"
    )
    print("-" * 100)

    for path, stats in valid[:top_n]:
        print(
            f"{path:<45.45} "
            f"{stats['complexity_total']:>7} "
            f"{stats['max_block_complexity']:>7} "
            f"{stats['complexity_blocks']:>7} "
            f"{stats['complexity_avg']:>8.2f} "
            f"{stats['loc']:>6} "
            f"{stats['mi']:>8.2f}"
        )


def print_per_file_metrics(results: dict[str, FileStats]) -> None:
    print("\n=== Per-file Metrics ===")

    valid = [(path, stats) for path, stats in results.items() if stats["error"] is None]
    valid.sort(key=lambda item: item[0].lower())

    for path, stats in valid:
        print(f"\n{path}")
        print(f"  LOC:                  {stats['loc']}")
        print(f"  SLOC:                 {stats['sloc']}")
        print(f"  LLOC:                 {stats['lloc']}")
        print(f"  Comments:             {stats['comments']}")
        print(f"  Multiline Strings:    {stats['multi']}")
        print(f"  Blank Lines:          {stats['blank']}")
        print(f"  Complexity Total:     {stats['complexity_total']}")
        print(f"  Complexity Blocks:    {stats['complexity_blocks']}")
        print(f"  Complexity Avg:       {stats['complexity_avg']:.2f}")
        print(f"  Max Block Complexity: {stats['max_block_complexity']}")
        print(f"  Maintainability:      {stats['mi']:.2f}")


def print_errors(results: dict[str, FileStats]) -> None:
    errors = [(path, stats["error"]) for path, stats in results.items() if stats["error"] is not None]

    if not errors:
        return

    print("\n=== Errors ===")
    for path, err in errors:
        print(f"{path}: {err}")


def main() -> None:
    project_path = input("Enter project folder path (or . for current folder): ").strip()
    if not project_path:
        project_path = "."

    results, folder_totals, total = analyze_project(project_path)

    print_project_summary(total)
    print_folder_summary(folder_totals)
    print_largest_files(results)
    print_most_complex_files(results)

    show_all = input("\nShow per-file metrics too? (y/n): ").strip().lower()
    if show_all == "y":
        print_per_file_metrics(results)

    print_errors(results)


if __name__ == "__main__":
    main()
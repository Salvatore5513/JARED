from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QGridLayout, QLabel, QVBoxLayout


class DashboardPanel(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)

        title = QLabel("<b>System Dashboard</b>")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        self.pipeline_value = QLabel("—")
        self.devices_value = QLabel("—")
        self.wake_value = QLabel("—")
        self.listening_value = QLabel("—")
        self.transcript_value = QLabel("—")
        self.intent_value = QLabel("—")
        self.action_value = QLabel("—")
        self.assistant_value = QLabel("—")
        self.tts_value = QLabel("—")

        grid = QGridLayout()
        grid.setColumnStretch(0, 0)
        grid.setColumnStretch(1, 1)

        grid.addWidget(QLabel("Voice Pipeline:"), 0, 0)
        grid.addWidget(self.pipeline_value, 0, 1)

        grid.addWidget(QLabel("Devices Loaded:"), 1, 0)
        grid.addWidget(self.devices_value, 1, 1)

        grid.addWidget(QLabel("Wake:"), 2, 0)
        grid.addWidget(self.wake_value, 2, 1)

        grid.addWidget(QLabel("Listening:"), 3, 0)
        grid.addWidget(self.listening_value, 3, 1)

        grid.addWidget(QLabel("Last Transcript:"), 4, 0)
        grid.addWidget(self.transcript_value, 4, 1)

        grid.addWidget(QLabel("Last Intent:"), 5, 0)
        grid.addWidget(self.intent_value, 5, 1)

        grid.addWidget(QLabel("Last Action:"), 6, 0)
        grid.addWidget(self.action_value, 6, 1)

        grid.addWidget(QLabel("Assistant Said:"), 7, 0)
        grid.addWidget(self.assistant_value, 7, 1)

        grid.addWidget(QLabel("TTS:"), 8, 0)
        grid.addWidget(self.tts_value, 8, 1)

        root = QVBoxLayout(self)
        root.addWidget(title)
        root.addLayout(grid)
        root.addStretch(1)

    def handle_event(self, topic: str, data: dict) -> None:
        data = data or {}

        if topic == "voice.pipeline":
            state = str(data.get("state", "—"))
            stt = str(data.get("stt", "—"))
            wake = str(data.get("wake", "—"))
            self.pipeline_value.setText(f"{state} | STT: {stt} | Wake: {wake}")
            return
        
        if topic == "ui.devices.snapshot":
            devices = data.get("devices", [])
            count = len(devices) if isinstance(devices, list) else 0
            self.devices_value.setText(str(count))
            return

        if topic == "voice.wake":
            confidence = data.get("confidence")
            reason = str(data.get("reason", ""))
            if confidence is None:
                self.wake_value.setText(reason or "detected")
            else:
                self.wake_value.setText(f"detected | conf={confidence:.3f} | {reason}")
            return

        if topic == "stt.listening":
            phase = str(data.get("phase", "listening"))
            self.listening_value.setText(phase)
            return

        if topic == "voice.transcript":
            text = str(data.get("text", ""))
            conf = data.get("confidence")
            final = bool(data.get("final", False))

            suffix = []
            suffix.append("final" if final else "partial")
            if conf is not None:
                suffix.append(f"conf={conf:.2f}")

            if text:
                self.transcript_value.setText(f"{text} ({', '.join(suffix)})")
            else:
                self.transcript_value.setText(f"— ({', '.join(suffix)})")
            return

        if topic == "nlp.intent":
            name = str(data.get("name", "—"))
            conf = data.get("confidence")
            slots = data.get("slots", {})

            if conf is None:
                self.intent_value.setText(f"{name} | slots={slots}")
            else:
                self.intent_value.setText(f"{name} | conf={conf:.2f} | slots={slots}")
            return

        if topic == "action.requested":
            action = str(data.get("action", data.get("kind", "requested")))
            self.action_value.setText(f"requested | {action}")
            return

        if topic == "action.policy_decided":
            decision = data.get("decision", {})
            allowed = decision.get("allowed", None)

            if allowed is True:
                self.action_value.setText("policy: allowed")
            elif allowed is False:
                reason = str(decision.get("reason_code", "denied"))
                self.action_value.setText(f"policy: denied | {reason}")
            else:
                self.action_value.setText(f"policy: {decision}")
            return

        if topic == "action.executed":
            self.action_value.setText("executed")
            return

        if topic == "action.verified":
            verification = data.get("verification", {}) or {}
            verified = verification.get("verified", None)
            method = str(verification.get("method", ""))
            self.action_value.setText(f"verified={verified} | method={method}")
            return

        if topic == "action.failed":
            stage = str(data.get("stage", "unknown"))
            code = str(data.get("code", "unknown"))
            self.action_value.setText(f"failed | stage={stage} | code={code}")
            return
        
        if topic == "assistant.say":
            text = str(data.get("text", "")).strip()
            self.assistant_value.setText(text or "—")
            return

        if topic == "tts.started":
            self.tts_value.setText("speaking")
            return

        if topic == "tts.completed":
            self.tts_value.setText("idle")
            return

        if topic == "tts.unavailable":
            reason = str(data.get("reason", "unavailable"))
            self.tts_value.setText(f"unavailable | {reason}")
            return
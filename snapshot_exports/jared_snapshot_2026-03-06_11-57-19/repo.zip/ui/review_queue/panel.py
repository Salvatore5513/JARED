from __future__ import annotations

import json

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QListWidget,
    QListWidgetItem,
    QTextEdit,
)


class ReviewQueuePanel(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)

        self._items: list[dict] = []

        title = QLabel("Review Queue")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self.clear)

        top = QHBoxLayout()
        top.addWidget(title)
        top.addStretch(1)
        top.addWidget(clear_btn)

        self.status = QLabel("Queued items: 0")

        self.listing = QListWidget()
        self.listing.currentRowChanged.connect(self._show_selected)

        self.details = QTextEdit()
        self.details.setReadOnly(True)

        root = QVBoxLayout(self)
        root.addLayout(top)
        root.addWidget(self.status)
        root.addWidget(self.listing)
        root.addWidget(self.details)

    def clear(self) -> None:
        self._items.clear()
        self.listing.clear()
        self.details.clear()
        self.status.setText("Queued items: 0")

    def handle_event(self, topic: str, data: dict) -> None:
        data = data or {}

        # Start by queueing failures and denials.
        if topic == "action.failed":
            self._add_item(
                kind="Action Failure",
                summary=f"{data.get('stage', 'unknown')} | {data.get('code', 'unknown')}",
                payload={"topic": topic, **data},
            )
            return

        if topic == "action.policy_decided":
            decision = data.get("decision", {}) or {}
            if decision.get("allowed") is False:
                self._add_item(
                    kind="Policy Denial",
                    summary=str(decision.get("reason_code", "DENIED")),
                    payload={"topic": topic, **data},
                )
            return

    def _add_item(self, *, kind: str, summary: str, payload: dict) -> None:
        entry = {
            "kind": kind,
            "summary": summary,
            "payload": payload,
        }
        self._items.append(entry)

        item = QListWidgetItem(f"{kind} — {summary}")
        self.listing.addItem(item)

        self.status.setText(f"Queued items: {len(self._items)}")

        if self.listing.count() == 1:
            self.listing.setCurrentRow(0)

    def _show_selected(self, row: int) -> None:
        if row < 0 or row >= len(self._items):
            self.details.clear()
            return

        entry = self._items[row]
        self.details.setPlainText(
            json.dumps(entry["payload"], indent=2, sort_keys=True, ensure_ascii=False)
        )
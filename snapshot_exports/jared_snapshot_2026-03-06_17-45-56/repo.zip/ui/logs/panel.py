from __future__ import annotations

import json
from datetime import datetime

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTextEdit


class LogsPanel(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)

        title = QLabel("Logs")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self.clear)

        top = QHBoxLayout()
        top.addWidget(title)
        top.addStretch(1)
        top.addWidget(clear_btn)

        self.output = QTextEdit()
        self.output.setReadOnly(True)

        root = QVBoxLayout(self)
        root.addLayout(top)
        root.addWidget(self.output)

    def clear(self) -> None:
        self.output.clear()

    def handle_event(self, topic: str, data: dict) -> None:
        timestamp = datetime.now().strftime("%H:%M:%S")

        if data is None:
            payload_text = "{}"
        else:
            try:
                payload_text = json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False)
            except TypeError:
                payload_text = repr(data)

        block = f"[{timestamp}] {topic}\n{payload_text}\n" + ("-" * 60)
        self.output.append(block)

        cursor = self.output.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        self.output.setTextCursor(cursor)
        self.output.ensureCursorVisible()
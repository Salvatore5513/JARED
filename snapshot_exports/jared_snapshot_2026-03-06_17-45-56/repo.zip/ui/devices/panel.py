from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTableWidget, QTableWidgetItem
)

from core.event_bus import EventBus


class DevicesPanel(QWidget):
    def __init__(self, bus: EventBus, parent=None) -> None:
        super().__init__(parent)
        self.bus = bus

        title = QLabel("Devices")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.refresh)

        top = QHBoxLayout()
        top.addWidget(title)
        top.addStretch(1)
        top.addWidget(refresh_btn)

        self.status = QLabel("Devices: (unknown)")

        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(
            ["device_id", "name", "room_id", "driver_kind", "enabled", "capabilities", "template_id"]
        )
        self.table.setSortingEnabled(True)

        root = QVBoxLayout(self)
        root.addLayout(top)
        root.addWidget(self.status)
        root.addWidget(self.table)

    def refresh(self) -> None:
        self.bus.publish("ui.devices.refresh")

    def handle_event(self, topic: str, data: dict) -> None:
        if topic != "ui.devices.snapshot":
            return

        devices = (data or {}).get("devices", []) or []
        if not isinstance(devices, list):
            devices = []

        self.status.setText(f"Devices: {len(devices)}")

        was_sorting = self.table.isSortingEnabled()
        self.table.setSortingEnabled(False)
        self.table.clearContents()
        self.table.setRowCount(len(devices))

        for r, d in enumerate(devices):
            if not isinstance(d, dict):
                d = {"raw": repr(d)}

            device_id = str(d.get("device_id", ""))
            name = str(d.get("name", ""))
            room_id = str(d.get("room_id", ""))
            driver_kind = str(d.get("driver_kind", ""))
            enabled = "Yes" if d.get("enabled", False) else "No"
            template_id = str(d.get("template_id", ""))

            caps = d.get("capabilities", {})
            if isinstance(caps, dict):
                caps_s = ", ".join(f"{k}={v}" for k, v in sorted(caps.items()))
            else:
                caps_s = str(caps)

            row_values = [
                device_id,
                name,
                room_id,
                driver_kind,
                enabled,
                caps_s,
                template_id,
            ]

            for c, text in enumerate(row_values):
                item = QTableWidgetItem(text)
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.table.setItem(r, c, item)

        self.table.resizeColumnsToContents()
        self.table.setSortingEnabled(was_sorting)
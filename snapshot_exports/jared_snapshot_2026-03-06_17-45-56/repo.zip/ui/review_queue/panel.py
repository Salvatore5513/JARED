from __future__ import annotations

import json

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QListWidget,
    QListWidgetItem,
    QTextEdit,
)


class ReviewQueuePanel(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)

        self._requests_by_id: dict[str, dict] = {}
        
        self._items: list[dict] = []

        title = QLabel("Review Queue")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self.clear)

        top = QHBoxLayout()
        top.addWidget(title)
        top.addStretch(1)
        top.addWidget(clear_btn)

        self.status = QLabel("Queued items: 0")

        self.listing = QListWidget()
        self.listing.currentRowChanged.connect(self._show_selected)

        self.details = QTextEdit()
        self.details.setReadOnly(True)

        root = QVBoxLayout(self)
        root.addLayout(top)
        root.addWidget(self.status)
        root.addWidget(self.listing)
        root.addWidget(self.details)

    def clear(self) -> None:
        self._items.clear()
        self.listing.clear()
        self.details.clear()
        self.status.setText("Queued items: 0")

    def _request_summary(self, request_id: str) -> str:
        item = self._requests_by_id.get(request_id, {}) or {}
        request = item.get("request", {}) or {}
        target = item.get("target", {}) or {}

        intent = str(request.get("intent_name", "unknown")).strip()
        slots = request.get("slots", {}) or {}

        state = str(
            slots.get("state", slots.get("power", slots.get("enabled", "")))
        ).strip()

        room_name = target.get("room_name")
        device_name = target.get("device_name")
        device_id = target.get("device_id")

        room_name = "" if room_name is None else str(room_name).strip()
        device_name = "" if device_name is None else str(device_name).strip()
        device_id = "" if device_id is None else str(device_id).strip()

        target_parts = []
        if room_name:
            target_parts.append(room_name)
        if device_name:
            target_parts.append(device_name)
        elif device_id:
            target_parts.append(device_id)

        target_text = " ".join(target_parts).strip()

        parts = [intent]
        if state:
            parts.append(state)
        if target_text:
            parts.append(f"-> {target_text}")

        summary = " ".join(parts).strip()
        return summary or request_id or "unknown request"
    def handle_event(self, topic: str, data: dict) -> None:
        data = data or {}

        if topic == "action.requested":
            request = data.get("request", {}) or {}
            target = data.get("target", {}) or {}
            request_id = str(request.get("request_id", "")).strip()

            if request_id:
                self._requests_by_id[request_id] = {
                    "request": request,
                    "target": target,
                }
            return

        # Start by queueing failures and denials.
        if topic == "action.failed":
            request_id = str(data.get("request_id", "")).strip()
            command = self._request_summary(request_id)
            stage = str(data.get("stage", "unknown"))
            code = str(data.get("code", "unknown"))
            details = str(data.get("details", "")).strip()

            summary = f"{command} | {stage} | {code}"
            if details:
                summary += f" | {details}"

            self._add_item(
                kind="Action Failure",
                summary=summary,
                payload={"topic": topic, "command": command, **data},
            )
            return

        if topic == "action.policy_decided":
            decision = data.get("decision", {}) or {}
            if decision.get("allowed") is False:
                request_id = str(data.get("request_id", "")).strip()
                command = self._request_summary(request_id)
                reason = str(decision.get("reason_code", "DENIED"))

                self._add_item(
                    kind="Policy Denial",
                    summary=f"{command} | {reason}",
                    payload={"topic": topic, "command": command, **data},
                )
            return
        
        if topic == "action.clarification_required":
            candidates = data.get("candidates", []) or []
            labels = [str(c.get("label", c.get("name", "?"))) for c in candidates if isinstance(c, dict)]
            original_target = str(data.get("original_target", "")).strip()

            summary = f"target={original_target}" if original_target else "Clarification needed"
            if labels:
                summary += " | " + ", ".join(labels)

            self._add_item(
                kind="Clarification Required",
                summary=summary,
                payload={"topic": topic, **data},
            )
            return

    def _add_item(self, *, kind: str, summary: str, payload: dict) -> None:
        entry = {
            "kind": kind,
            "summary": summary,
            "payload": payload,
        }
        self._items.append(entry)

        item = QListWidgetItem(f"{kind} — {summary}")
        self.listing.addItem(item)

        self.status.setText(f"Queued items: {len(self._items)}")

        if self.listing.count() == 1:
            self.listing.setCurrentRow(0)

    def _show_selected(self, row: int) -> None:
        if row < 0 or row >= len(self._items):
            self.details.clear()
            return

        entry = self._items[row]
        self.details.setPlainText(
            json.dumps(entry["payload"], indent=2, sort_keys=True, ensure_ascii=False)
        )
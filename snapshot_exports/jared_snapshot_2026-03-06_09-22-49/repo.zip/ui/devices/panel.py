from __future__ import annotations

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTableWidget, QTableWidgetItem
)

from core.event_bus import Event, EventBus


class DevicesPanel(QWidget):
    def __init__(self, bus: EventBus, parent=None) -> None:
        super().__init__(parent)
        self.bus = bus

        title = QLabel("Devices")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.refresh)

        top = QHBoxLayout()
        top.addWidget(title)
        top.addStretch(1)
        top.addWidget(refresh_btn)

        self.status = QLabel("Devices: (unknown)")

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["device_id", "name", "room_id", "driver", "capabilities", "meta"]
        )
        self.table.setSortingEnabled(True)

        root = QVBoxLayout(self)
        root.addLayout(top)
        root.addWidget(self.status)   # <-- status goes AFTER root exists
        root.addWidget(self.table)

        # Listen for snapshots published by bootstrap/device layer
        self.bus.subscribe("ui.devices.snapshot", self._on_snapshot)

        # Auto-refresh once on open
        QTimer.singleShot(0, self.refresh)

    def refresh(self) -> None:
        self.bus.publish("ui.devices.refresh")

    def _on_snapshot(self, evt: Event) -> None:
        devices = (evt.data or {}).get("devices", []) or []
        if not isinstance(devices, list):
            devices = []

        self.status.setText(f"Devices: {len(devices)}")
        
        self.table.setRowCount(len(devices))

        for r, d in enumerate(devices):
            if not isinstance(d, dict):
                d = {"raw": repr(d)}

            device_id = str(d.get("device_id", ""))
            name = str(d.get("name", d.get("label", "")))
            room_id = str(d.get("room_id", ""))
            driver = str(d.get("driver", d.get("driver_id", "")))

            caps = d.get("capabilities", [])
            if isinstance(caps, list):
                caps_s = ", ".join(str(x) for x in caps)
            else:
                caps_s = str(caps)

            meta = d.get("meta", d.get("extras", d.get("raw", "")))
            meta_s = str(meta)

            for c, text in enumerate([device_id, name, room_id, driver, caps_s, meta_s]):
                it = QTableWidgetItem(text)
                it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.table.setItem(r, c, it)
from __future__ import annotations

from PySide6.QtWidgets import QWidget, QVBoxLayout, QTextEdit


class LogsPanel(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)

        self.view = QTextEdit()
        self.view.setReadOnly(True)

        layout.addWidget(self.view)

    def handle_event(self, topic: str, data: dict):
        self.view.append(f"{topic} -> {data}")
from __future__ import annotations

from PySide6.QtWidgets import QMainWindow, QTabWidget

from ui.dashboard.panel import DashboardPanel
from ui.logs.panel import LogsPanel
from ui.devices.panel import DevicesPanel


class MainWindow(QMainWindow):
    def __init__(self, bridge):
        super().__init__()
        self.setWindowTitle("JARED Command Center")
        self.resize(1200, 800)

        tabs = QTabWidget()

        # Panels
        self.dashboard = DashboardPanel()
        self.logs = LogsPanel()
        self.devices = DevicesPanel(bridge.bus)

        tabs.addTab(self.dashboard, "Dashboard")
        tabs.addTab(self.devices, "Devices")
        tabs.addTab(self.logs, "Logs")

        self.setCentralWidget(tabs)

        # Route all bus events to dashboard + logs
        bridge.event_received.connect(self._route_event)

    def _route_event(self, topic: str, data: dict):
        if hasattr(self.dashboard, "handle_event"):
            self.dashboard.handle_event(topic, data)

        if hasattr(self.logs, "handle_event"):
            self.logs.handle_event(topic, data)
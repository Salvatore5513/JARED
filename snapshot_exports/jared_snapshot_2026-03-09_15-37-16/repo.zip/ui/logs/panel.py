from __future__ import annotations

import json
from datetime import datetime
from html import escape

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTextEdit,
    QLineEdit,
    QCheckBox,
    QSpinBox,
    QButtonGroup,
)


class LogsPanel(QWidget):
    CATEGORY_ALL = "ALL"
    CATEGORY_VOICE = "VOICE"
    CATEGORY_DEVICE = "DEVICE"
    CATEGORY_ACTION = "ACTION"
    CATEGORY_SYSTEM = "SYSTEM"
    CATEGORY_ERROR = "ERROR"

    SEVERITY_INFO = "INFO"
    SEVERITY_SUCCESS = "SUCCESS"
    SEVERITY_WARNING = "WARNING"
    SEVERITY_ERROR = "ERROR"

    SEVERITY_COLORS = {
        SEVERITY_INFO: "#9aa0a6",     # gray
        SEVERITY_SUCCESS: "#34a853",  # green
        SEVERITY_WARNING: "#f29900",  # orange
        SEVERITY_ERROR: "#ea4335",    # red
    }

    CATEGORY_COLORS = {
        CATEGORY_ALL: "#9aa0a6",
        CATEGORY_VOICE: "#8ab4f8",
        CATEGORY_DEVICE: "#81c995",
        CATEGORY_ACTION: "#fdd663",
        CATEGORY_SYSTEM: "#c58af9",
        CATEGORY_ERROR: "#ea4335",
    }

    def __init__(self, parent=None) -> None:
        super().__init__(parent)

        self._entries: list[dict] = []
        self._paused = False
        self._selected_category = self.CATEGORY_ALL

        title = QLabel("Logs")
        title.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        self.topic_filter = QLineEdit()
        self.topic_filter.setPlaceholderText("Filter topic (example: action. or ui.)")
        self.topic_filter.textChanged.connect(self._render)

        self.text_filter = QLineEdit()
        self.text_filter.setPlaceholderText("Filter payload text")
        self.text_filter.textChanged.connect(self._render)

        self.autoscroll = QCheckBox("Auto-scroll")
        self.autoscroll.setChecked(True)

        self.pause_btn = QPushButton("Pause")
        self.pause_btn.setCheckable(True)
        self.pause_btn.toggled.connect(self._toggle_pause)

        self.max_entries = QSpinBox()
        self.max_entries.setRange(100, 5000)
        self.max_entries.setSingleStep(100)
        self.max_entries.setValue(1000)
        self.max_entries.valueChanged.connect(self._trim_and_render)

        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self.clear)

        top = QHBoxLayout()
        top.addWidget(title)
        top.addStretch(1)
        top.addWidget(QLabel("Topic:"))
        top.addWidget(self.topic_filter, 2)
        top.addWidget(QLabel("Text:"))
        top.addWidget(self.text_filter, 2)
        top.addWidget(QLabel("Keep:"))
        top.addWidget(self.max_entries)
        top.addWidget(self.autoscroll)
        top.addWidget(self.pause_btn)
        top.addWidget(clear_btn)

        self.category_buttons: dict[str, QPushButton] = {}
        self.category_group = QButtonGroup(self)
        self.category_group.setExclusive(True)

        category_bar = QHBoxLayout()
        category_bar.addWidget(QLabel("Category:"))

        for name in (
            self.CATEGORY_ALL,
            self.CATEGORY_VOICE,
            self.CATEGORY_DEVICE,
            self.CATEGORY_ACTION,
            self.CATEGORY_SYSTEM,
            self.CATEGORY_ERROR,
        ):
            btn = QPushButton(name)
            btn.setCheckable(True)
            btn.clicked.connect(lambda checked, category=name: self._set_category(category))
            self.category_group.addButton(btn)
            self.category_buttons[name] = btn
            category_bar.addWidget(btn)

        self.category_buttons[self.CATEGORY_ALL].setChecked(True)
        category_bar.addStretch(1)

        self.status = QLabel("Entries: 0")

        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)

        root = QVBoxLayout(self)
        root.addLayout(top)
        root.addLayout(category_bar)
        root.addWidget(self.status)
        root.addWidget(self.output)

        self._apply_button_styles()
        self._render()

    def clear(self) -> None:
        self._entries.clear()
        self.output.clear()
        self.status.setText("Entries: 0")

    def handle_event(self, topic: str, data: dict) -> None:
        payload = data if data is not None else {}
        payload_json = self._safe_json(payload)
        category = self._classify_category(str(topic), payload)
        severity = self._classify_severity(str(topic), payload)

        entry = {
            "timestamp": datetime.now().strftime("%H:%M:%S"),
            "topic": str(topic),
            "data": payload,
            "payload_json": payload_json,
            "category": category,
            "severity": severity,
        }

        self._entries.append(entry)
        self._trim_entries()

        if not self._paused:
            self._render()
        else:
            self.status.setText(f"Entries: {len(self._entries)} total (paused)")

    def _toggle_pause(self, paused: bool) -> None:
        self._paused = paused
        self.pause_btn.setText("Resume" if paused else "Pause")
        if not paused:
            self._render()
        else:
            self.status.setText(f"Entries: {len(self._entries)} total (paused)")

    def _set_category(self, category: str) -> None:
        self._selected_category = category
        self._apply_button_styles()
        self._render()

    def _apply_button_styles(self) -> None:
        for name, btn in self.category_buttons.items():
            color = self.CATEGORY_COLORS.get(name, "#9aa0a6")
            checked = name == self._selected_category

            if checked:
                btn.setStyleSheet(
                    f"""
                    QPushButton {{
                        background-color: {color};
                        color: #111111;
                        font-weight: 700;
                        border: 1px solid {color};
                        border-radius: 4px;
                        padding: 4px 10px;
                    }}
                    """
                )
            else:
                btn.setStyleSheet(
                    f"""
                    QPushButton {{
                        background-color: #202124;
                        color: {color};
                        border: 1px solid #3c4043;
                        border-radius: 4px;
                        padding: 4px 10px;
                    }}
                    QPushButton:hover {{
                        border: 1px solid {color};
                    }}
                    """
                )

    def _trim_entries(self) -> None:
        keep = int(self.max_entries.value())
        if len(self._entries) > keep:
            self._entries = self._entries[-keep:]

    def _trim_and_render(self) -> None:
        self._trim_entries()
        self._render()

    def _render(self) -> None:
        topic_text = self.topic_filter.text().strip().lower()
        payload_text = self.text_filter.text().strip().lower()

        rendered_blocks: list[str] = []
        shown = 0

        for entry in self._entries:
            topic = entry["topic"]
            payload_json = entry["payload_json"]
            category = entry["category"]
            severity = entry["severity"]

            if self._selected_category != self.CATEGORY_ALL and category != self._selected_category:
                continue

            if topic_text and topic_text not in topic.lower():
                continue

            if payload_text and payload_text not in payload_json.lower() and payload_text not in topic.lower():
                continue

            rendered_blocks.append(self._render_entry_html(entry))
            shown += 1

        if rendered_blocks:
            html = (
                "<html><body style='background:#111111; color:#e8eaed; "
                "font-family:Consolas, Menlo, monospace; font-size:12px;'>"
                + "".join(rendered_blocks)
                + "</body></html>"
            )
        else:
            html = (
                "<html><body style='background:#111111; color:#9aa0a6; "
                "font-family:Consolas, Menlo, monospace; font-size:12px;'>"
                "<div style='padding:8px;'>No log entries match current filters.</div>"
                "</body></html>"
            )

        self.output.setHtml(html)

        paused_suffix = " (paused)" if self._paused else ""
        self.status.setText(
            f"Entries: {shown} shown / {len(self._entries)} total | "
            f"Category: {self._selected_category} | Keep: {self.max_entries.value()}{paused_suffix}"
        )

        if self.autoscroll.isChecked():
            cursor = self.output.textCursor()
            cursor.movePosition(cursor.MoveOperation.End)
            self.output.setTextCursor(cursor)
            self.output.ensureCursorVisible()

    def _render_entry_html(self, entry: dict) -> str:
        ts = escape(str(entry["timestamp"]))
        topic = escape(str(entry["topic"]))
        category = escape(str(entry["category"]))
        severity = str(entry["severity"])
        payload_json = escape(str(entry["payload_json"]))

        sev_color = self.SEVERITY_COLORS.get(severity, "#9aa0a6")

        return (
            "<div style='margin:0 0 8px 0; padding:8px; border:1px solid #2a2a2a; "
            "border-radius:6px; background:#171717;'>"
            f"<div style='margin-bottom:4px;'>"
            f"<span style='color:#9aa0a6;'>[{ts}]</span> "
            f"<span style='color:#8ab4f8; font-weight:600;'>{topic}</span> "
            f"<span style='color:#7f8c8d;'>|</span> "
            f"<span style='color:#c58af9;'>{category}</span> "
            f"<span style='color:#7f8c8d;'>|</span> "
            f"<span style='color:{sev_color}; font-weight:700;'>{severity}</span>"
            f"</div>"
            f"<pre style='margin:0; white-space:pre-wrap; color:#e8eaed;'>{payload_json}</pre>"
            "</div>"
        )

    def _safe_json(self, payload: object) -> str:
        try:
            return json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False, default=str)
        except TypeError:
            return repr(payload)

    def _classify_category(self, topic: str, payload: dict) -> str:
        t = topic.lower()

        if self._looks_like_error(topic, payload):
            return self.CATEGORY_ERROR

        if t.startswith(("voice.", "stt.", "tts.", "nlp.", "assistant.")):
            return self.CATEGORY_VOICE

        if t.startswith(("device.", "devices.")):
            return self.CATEGORY_DEVICE

        if t.startswith(("action.", "review.")):
            return self.CATEGORY_ACTION

        if t.startswith(("system.", "ui.", "app.", "boot.", "ctx.")):
            return self.CATEGORY_SYSTEM

        return self.CATEGORY_SYSTEM

    def _classify_severity(self, topic: str, payload: dict) -> str:
        t = topic.lower()

        if self._looks_like_error(topic, payload):
            return self.SEVERITY_ERROR

        if any(word in t for word in ("warning", "warn", "retry", "expired")):
            return self.SEVERITY_WARNING

        if payload.get("ok") is True:
            return self.SEVERITY_SUCCESS

        driver_result = payload.get("driver_result")
        if isinstance(driver_result, dict) and driver_result.get("ok") is True:
            return self.SEVERITY_SUCCESS

        verification = payload.get("verification")
        if isinstance(verification, dict) and verification.get("verified") is True:
            return self.SEVERITY_SUCCESS

        if any(word in t for word in ("executed", "verified", "approved", "completed", "online", "connected")):
            return self.SEVERITY_SUCCESS

        return self.SEVERITY_INFO

    def _looks_like_error(self, topic: str, payload: dict) -> bool:
        t = topic.lower()

        if any(word in t for word in ("error", "failed", "denied", "exception", "critical")):
            return True

        if payload.get("ok") is False:
            return True

        if payload.get("success") is False:
            return True

        if payload.get("error"):
            return True

        if payload.get("exception"):
            return True

        if payload.get("code") in {"ERROR", "FAILED", "VERIFY_FAILED", "NO_DRIVER"}:
            return True

        driver_result = payload.get("driver_result")
        if isinstance(driver_result, dict):
            if driver_result.get("ok") is False:
                return True
            if driver_result.get("driver_code") in {"NO_DRIVER", "ERROR", "FAILED"}:
                return True

        return False